DROP TABLE `wwwsqldesigner`;

CREATE TABLE `wwwsqldesigner` (
  `keyword` varchar(30) NOT NULL,
  `data` string,
  `dt` timestamp,
  PRIMARY KEY  (`keyword`)
);
